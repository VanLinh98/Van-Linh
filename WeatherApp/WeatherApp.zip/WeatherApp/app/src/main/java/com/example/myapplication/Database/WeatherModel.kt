package com.example.myapplication.Database

data class WeatherModel(
    val tempC : String,
    val weatherDesc : String,
    val humidity: String,
    val weatherIconUrl: String
)