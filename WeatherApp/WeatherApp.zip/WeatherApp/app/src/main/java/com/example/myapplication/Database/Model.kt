package com.example.myapplication.Database


data class Model (var City: String)