package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.View
import android.widget.EditText
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.Adapter.AdapterHistory
import com.example.myapplication.Database.CityModel
import com.example.myapplication.View.WordViewModel
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity()  {

    lateinit var wordViewModel: WordViewModel
    var arraylist = ArrayList<CityModel>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val adapter1 = AdapterHistory(arraylist)
        rv_history.adapter = adapter1
        rv_history.layoutManager = LinearLayoutManager(this@MainActivity)
        rv_history.setLayoutManager(LinearLayoutManager(this@MainActivity, LinearLayoutManager.VERTICAL, false))

        wordViewModel = ViewModelProvider(this).get(WordViewModel::class.java)
        wordViewModel.allWords.observe(this, Observer<List<CityModel>> {
            val list : MutableList<CityModel> = mutableListOf()
            for (i in 0..it.size-1)
            {
                list.add(0,it.get(i))
            }
            adapter1.setWords(list)
        })
    }


    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val menuInflater = menuInflater
        menuInflater.inflate(R.menu.option_menu,menu)
        val searchView : SearchView = menu!!.findItem(R.id.mnuSearch).actionView as SearchView
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {

            override fun onQueryTextSubmit(query: String): Boolean {
                tvhistory.visibility = View.GONE
                arraylist = wordViewModel.getSearch("http://api.worldweatheronline.com/premium/v1/search.ashx?format=json&key=e2093a0d363d40d7a4982453202704&query="+query+"")
                val adapter = AdapterHistory(arraylist)
                rv_history.adapter = adapter
                rv_history.layoutManager = LinearLayoutManager(this@MainActivity)
                rv_history.setLayoutManager(LinearLayoutManager(this@MainActivity, LinearLayoutManager.VERTICAL, false))
               return true
            }
            override fun onQueryTextChange(newText: String): Boolean {
                return true
            }
        })

        return super.onCreateOptionsMenu(menu)
    }

    override fun onRestart() {
        tvhistory.visibility=View.VISIBLE
        val adapter1 = AdapterHistory(arraylist)
        rv_history.adapter = adapter1
        rv_history.layoutManager = LinearLayoutManager(this@MainActivity)
        rv_history.setLayoutManager(LinearLayoutManager(this@MainActivity, LinearLayoutManager.VERTICAL, false))

        wordViewModel = ViewModelProvider(this).get(WordViewModel::class.java)
        wordViewModel.allWords.observe(this, Observer<List<CityModel>> {
            val list : MutableList<CityModel> = mutableListOf()
            for (i in 0..it.size-1)
            {
                list.add(0,it.get(i))
            }
            adapter1.setWords(list)
        })

        super.onRestart()
    }
}
